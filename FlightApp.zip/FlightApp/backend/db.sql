CREATE TABLE flights (
  id SERIAL PRIMARY KEY,
  airline VARCHAR(255),
  departure VARCHAR(255),
  arrival VARCHAR(255),
  price DECIMAL
);
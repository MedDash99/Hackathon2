const express = require("express");
const Amadeus = require("amadeus");
require("dotenv").config();

const router = express.Router();

// Initialize Amadeus API
const amadeus = new Amadeus({
  clientId: process.env.AMADEUS_API_KEY,
  clientSecret: process.env.AMADEUS_API_SECRET,
});

// ✅ API Route: Search for flights using Amadeus
router.get("/search", async (req, res) => {
  try {
    const { origin, destination, date } = req.query;

    if (!origin || !destination || !date) {
      return res.status(400).json({ error: "Missing required parameters (origin, destination, date)" });
    }

    const response = await amadeus.shopping.flightOffersSearch.get({
      originLocationCode: origin,
      destinationLocationCode: destination,
      departureDate: date,
      adults: 1,
      travelClass: "ECONOMY",
      currencyCode: "USD",
    });

    res.json(response.data);
  } catch (error) {
    console.error("❌ Error fetching flights from Amadeus:", error);
    res.status(500).json({ error: "Failed to fetch flight data", details: error.message });
  }
});

module.exports = router;

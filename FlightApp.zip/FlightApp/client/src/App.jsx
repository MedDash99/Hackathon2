import { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [flights, setFlights] = useState([]);
  const [departure, setDeparture] = useState("JFK");
  const [arrival, setArrival] = useState("LAX");
  const [date, setDate] = useState("2025-04-11");

  const fetchFlights = async () => {
    try {
      const res = await axios.get("/api/flights/search", {
        params: { origin: departure, destination: arrival, date },
      });
      setFlights(res.data);
    } catch (err) {
      console.error("Error fetching flights:", err);
    }
  };

  useEffect(() => {
    fetchFlights();
  }, []);

  return (
    <div>
      <h1>Flight Search</h1>
      <div>
        <input 
          type="text" 
          value={departure} 
          onChange={(e) => setDeparture(e.target.value)} 
          placeholder="Departure (e.g., JFK)"
        />
        <input 
          type="text" 
          value={arrival} 
          onChange={(e) => setArrival(e.target.value)} 
          placeholder="Arrival (e.g., LAX)"
        />
        <input 
          type="date" 
          value={date} 
          onChange={(e) => setDate(e.target.value)}
        />
        <button onClick={fetchFlights}>Search Flights</button>
      </div>

      <ul>
        {flights.length > 0 ? (
          flights.map((flight, index) => (
            <li key={index}>
              {flight.itineraries[0].segments[0].departure.iataCode} →{" "}
              {flight.itineraries[0].segments[0].arrival.iataCode} (${flight.price.total})
            </li>
          ))
        ) : (
          <p>No flights found.</p> 
        )}
      </ul>
    </div>
  );
}

export default App;
